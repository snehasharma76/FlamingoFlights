import { Component } from '@angular/core';

@Component({
  selector: 'app-fare-summary',
  templateUrl: './fare-summary.component.html',
  styleUrls: ['./fare-summary.component.scss']
})
export class FareSummaryComponent {

}
