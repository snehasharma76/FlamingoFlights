export class FlightSearch{
    Origin:string = "";
    Destination:string = "";
    TimeOfDeparture:string = "";
    NumberOfPassengers:string = "";
}