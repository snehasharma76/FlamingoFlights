export class Passenger {
    passengerId?: number;
    pnrNo?: number;
    firstName?: string;
    lastName?: string;
    age?: number;
    aadharNo?: string;
}
